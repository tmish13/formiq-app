"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Camera, Play, TrendingUp, Award, Target, Brain, ChevronRight, Activity, FlameIcon as Fire } from "lucide-react"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Header } from "@/components/header"

// Enhanced mock data with realistic user progression
const userData = {
  name: "Alex",
  streak: 12,
  totalWorkouts: 47,
  todayFormScore: 89,
  weeklyImprovement: 15,
  currentLevel: "Intermediate",
  nextMilestone: "Advanced (95% avg)",
}

const todayStats = [
  {
    label: "Today's Form",
    value: "89%",
    change: "+6%",
    icon: Target,
    color: "bg-blue-500",
    bgColor: "bg-blue-50 dark:bg-blue-900/20",
  },
  {
    label: "Total Workouts",
    value: "47",
    change: "+2 this week",
    icon: Activity,
    color: "bg-green-500",
    bgColor: "bg-green-50 dark:bg-green-900/20",
  },
  {
    label: "Current Streak",
    value: `${userData.streak}d`,
    change: "Personal best!",
    icon: Fire,
    color: "bg-orange-500",
    bgColor: "bg-orange-50 dark:bg-orange-900/20",
  },
]

const aiCoachTips = [
  {
    icon: "💪",
    title: "Squat Depth Mastery",
    message: "Your depth improved 15% this week! Try adding pause squats to build strength at the bottom position.",
    category: "Technique",
  },
  {
    icon: "🎯",
    title: "Ready for Progression",
    message:
      "Your form consistency is excellent at current weight. Consider adding 5-10lbs to your squat next session.",
    category: "Progression",
  },
  {
    icon: "⚡",
    title: "Tempo Optimization",
    message:
      "Your controlled descent is perfect. Focus on explosive concentric movement to maximize power development.",
    category: "Performance",
  },
]

const quickActions = [
  {
    title: "Start Form Check",
    subtitle: "AI-powered analysis",
    icon: Camera,
    color: "from-blue-500 to-blue-600",
    action: "record",
  },
  {
    title: "Quick Workout",
    subtitle: "15-min session",
    icon: Play,
    color: "from-green-500 to-green-600",
    action: "workout",
  },
  {
    title: "View Progress",
    subtitle: "Track improvements",
    icon: TrendingUp,
    color: "from-purple-500 to-purple-600",
    action: "progress",
  },
]

const recentActivity = [
  {
    exercise: "Squat",
    score: 89,
    date: "Today",
    improvement: "+6%",
    issues: ["Excellent depth", "Minor knee tracking"],
  },
  {
    exercise: "Deadlift",
    score: 94,
    date: "Yesterday",
    improvement: "+3%",
    issues: ["Perfect form", "Strong lockout"],
  },
  {
    exercise: "Bench Press",
    score: 82,
    date: "2 days ago",
    improvement: "+8%",
    issues: ["Good bar path", "Improve leg drive"],
  },
]

export default function Dashboard() {
  const [currentTip, setCurrentTip] = useState(0)

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      <Header />

      <div className="px-4 py-6 space-y-6">
        {/* Welcome Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Hey {userData.name}! 👋</h1>
              <p className="text-gray-600 dark:text-gray-400">Ready to perfect your form?</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400">
                <Fire className="w-3 h-3 mr-1" />
                {userData.streak}d streak
              </Badge>
            </div>
          </div>

          {/* Level Progress */}
          <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-blue-100 text-sm">Current Level</p>
                  <p className="text-xl font-bold">{userData.currentLevel}</p>
                </div>
                <div className="text-right">
                  <p className="text-blue-100 text-sm">Form Score</p>
                  <p className="text-2xl font-bold">{userData.todayFormScore}%</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-blue-100">
                  <span>Progress to {userData.nextMilestone.split("(")[0]}</span>
                  <span>89/95%</span>
                </div>
                <Progress value={89} className="h-2 bg-blue-400/30" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Today's Stats */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Today's Stats</h2>
          <div className="grid grid-cols-1 gap-3">
            {todayStats.map((stat, index) => (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                      <stat.icon className={`w-6 h-6 text-${stat.color.split("-")[1]}-600`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{stat.label}</p>
                        <p className="text-xs text-green-600 font-medium">{stat.change}</p>
                      </div>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* AI Coach Tip */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-base">
              <Brain className="w-5 h-5 text-purple-600" />
              <span>AI Coach Tip</span>
              <Badge variant="secondary" className="bg-purple-100 text-purple-800 text-xs">
                Personalized
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-4">
              <div className="flex items-start space-x-3 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
                <div className="text-2xl">{aiCoachTips[currentTip].icon}</div>
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-1">{aiCoachTips[currentTip].title}</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                    {aiCoachTips[currentTip].message}
                  </p>
                  <Badge variant="outline" className="mt-2 text-xs">
                    {aiCoachTips[currentTip].category}
                  </Badge>
                </div>
              </div>
              <div className="flex justify-center space-x-2">
                {aiCoachTips.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentTip(index)}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentTip ? "bg-purple-600" : "bg-gray-300 dark:bg-gray-600"
                    }`}
                  />
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Quick Actions</h2>
          <div className="grid grid-cols-1 gap-3">
            {quickActions.map((action, index) => (
              <Card key={index} className="border-0 shadow-sm overflow-hidden">
                <CardContent className="p-0">
                  <Button
                    className={`w-full h-20 bg-gradient-to-r ${action.color} text-white border-0 rounded-lg flex items-center justify-between p-6 hover:opacity-90 transition-opacity`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                        <action.icon className="w-6 h-6" />
                      </div>
                      <div className="text-left">
                        <p className="font-semibold text-lg">{action.title}</p>
                        <p className="text-white/80 text-sm">{action.subtitle}</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Activity</h2>
            <Button variant="ghost" size="sm" className="text-blue-600">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <Card key={index} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                        <Target className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-white">{activity.exercise}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">{activity.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-bold text-gray-900 dark:text-white">{activity.score}%</span>
                        <span className="text-sm text-green-600 font-medium">{activity.improvement}</span>
                      </div>
                      <div className="flex space-x-1 mt-1">
                        {activity.issues.slice(0, 2).map((issue, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {issue.length > 12 ? issue.substring(0, 12) + "..." : issue}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Weekly Challenge */}
        <Card className="border-0 shadow-sm bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 dark:text-white">Weekly Challenge</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">Complete 5 form checks this week</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Progress value={60} className="flex-1 h-2" />
                  <span className="text-sm font-medium text-gray-600 dark:text-gray-400">3/5</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNavigation activeTab="home" />
    </div>
  )
}
