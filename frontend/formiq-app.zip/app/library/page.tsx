"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Filter, Play, BookOpen, Target, Dumbbell, Timer, Flame, Star, Clock } from "lucide-react"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Header } from "@/components/header"

const exerciseLibrary = [
  {
    id: 1,
    name: "Squat",
    category: "Lower Body",
    difficulty: "Beginner",
    duration: "5-10 min",
    muscleGroups: ["Quadriceps", "Glutes", "Core"],
    description: "Fundamental lower body compound movement",
    thumbnail: "/placeholder.svg?height=120&width=160",
    videoUrl: "/demo-squat.mp4",
    keyPoints: ["Feet shoulder-width apart", "Knees track over toes", "Hip hinge movement"],
    commonMistakes: ["Knee valgus", "Forward lean", "Incomplete depth"],
    aiAnalysis: true,
    popularity: 95,
    userRating: 4.8,
  },
  {
    id: 2,
    name: "Deadlift",
    category: "Full Body",
    difficulty: "Intermediate",
    duration: "8-12 min",
    muscleGroups: ["Hamstrings", "Glutes", "Back", "Core"],
    description: "Hip hinge movement pattern for posterior chain",
    thumbnail: "/placeholder.svg?height=120&width=160",
    videoUrl: "/demo-deadlift.mp4",
    keyPoints: ["Neutral spine", "Bar close to body", "Hip hinge pattern"],
    commonMistakes: ["Rounded back", "Bar drift", "Incomplete lockout"],
    aiAnalysis: true,
    popularity: 88,
    userRating: 4.7,
  },
  {
    id: 3,
    name: "Push-up",
    category: "Upper Body",
    difficulty: "Beginner",
    duration: "3-8 min",
    muscleGroups: ["Chest", "Shoulders", "Triceps", "Core"],
    description: "Bodyweight upper body pressing movement",
    thumbnail: "/placeholder.svg?height=120&width=160",
    videoUrl: "/demo-pushup.mp4",
    keyPoints: ["Straight body line", "Full range of motion", "Controlled tempo"],
    commonMistakes: ["Sagging hips", "Partial range", "Head position"],
    aiAnalysis: true,
    popularity: 92,
    userRating: 4.6,
  },
  {
    id: 4,
    name: "Overhead Press",
    category: "Upper Body",
    difficulty: "Intermediate",
    duration: "6-10 min",
    muscleGroups: ["Shoulders", "Triceps", "Core"],
    description: "Vertical pressing movement for shoulder development",
    thumbnail: "/placeholder.svg?height=120&width=160",
    videoUrl: "/demo-ohp.mp4",
    keyPoints: ["Stable base", "Vertical bar path", "Full lockout"],
    commonMistakes: ["Forward head", "Arched back", "Incomplete lockout"],
    aiAnalysis: true,
    popularity: 76,
    userRating: 4.5,
  },
  {
    id: 5,
    name: "Plank",
    category: "Core",
    difficulty: "Beginner",
    duration: "2-5 min",
    muscleGroups: ["Core", "Shoulders", "Glutes"],
    description: "Isometric core strengthening exercise",
    thumbnail: "/placeholder.svg?height=120&width=160",
    videoUrl: "/demo-plank.mp4",
    keyPoints: ["Straight body line", "Engaged core", "Neutral neck"],
    commonMistakes: ["Sagging hips", "Raised hips", "Holding breath"],
    aiAnalysis: true,
    popularity: 84,
    userRating: 4.4,
  },
  {
    id: 6,
    name: "Lunges",
    category: "Lower Body",
    difficulty: "Beginner",
    duration: "4-8 min",
    muscleGroups: ["Quadriceps", "Glutes", "Calves"],
    description: "Unilateral lower body strengthening movement",
    thumbnail: "/placeholder.svg?height=120&width=160",
    videoUrl: "/demo-lunges.mp4",
    keyPoints: ["90-degree angles", "Vertical torso", "Controlled descent"],
    commonMistakes: ["Forward lean", "Knee collapse", "Short steps"],
    aiAnalysis: true,
    popularity: 79,
    userRating: 4.3,
  },
]

const workoutTemplates = [
  {
    id: 1,
    name: "Beginner Full Body",
    duration: "25 min",
    exercises: 5,
    difficulty: "Beginner",
    description: "Perfect introduction to strength training",
    exercises_list: ["Squat", "Push-up", "Plank", "Lunges", "Glute Bridge"],
    category: "Strength",
  },
  {
    id: 2,
    name: "Upper Body Power",
    duration: "30 min",
    exercises: 6,
    difficulty: "Intermediate",
    description: "Build upper body strength and muscle",
    exercises_list: ["Push-up", "Overhead Press", "Pike Push-up", "Tricep Dips", "Plank", "Mountain Climbers"],
    category: "Strength",
  },
  {
    id: 3,
    name: "Lower Body Blast",
    duration: "35 min",
    exercises: 7,
    difficulty: "Advanced",
    description: "Intense lower body workout",
    exercises_list: ["Squat", "Deadlift", "Lunges", "Single-leg RDL", "Calf Raises", "Wall Sit", "Jump Squats"],
    category: "Strength",
  },
]

const categories = ["All", "Upper Body", "Lower Body", "Full Body", "Core"]
const difficulties = ["All", "Beginner", "Intermediate", "Advanced"]

export default function ExerciseLibrary() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [selectedDifficulty, setSelectedDifficulty] = useState("All")
  const [showFilters, setShowFilters] = useState(false)

  const filteredExercises = exerciseLibrary.filter((exercise) => {
    const matchesSearch =
      exercise.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exercise.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "All" || exercise.category === selectedCategory
    const matchesDifficulty = selectedDifficulty === "All" || exercise.difficulty === selectedDifficulty

    return matchesSearch && matchesCategory && matchesDifficulty
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-800"
      case "Intermediate":
        return "bg-yellow-100 text-yellow-800"
      case "Advanced":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Upper Body":
        return <Dumbbell className="w-4 h-4" />
      case "Lower Body":
        return <Target className="w-4 h-4" />
      case "Full Body":
        return <Flame className="w-4 h-4" />
      case "Core":
        return <Timer className="w-4 h-4" />
      default:
        return <Dumbbell className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      <Header />

      <div className="px-4 py-6 space-y-6">
        {/* Library Header */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Exercise Library</h1>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              <BookOpen className="w-3 h-3 mr-1" />
              {exerciseLibrary.length} exercises
            </Badge>
          </div>

          {/* Search and Filters */}
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search exercises..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12"
              />
            </div>

            <div className="flex items-center space-x-2 overflow-x-auto pb-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="flex-shrink-0"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>

              {/* Category Pills */}
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="flex-shrink-0 text-xs"
                >
                  {category}
                </Button>
              ))}
            </div>

            {/* Expanded Filters */}
            {showFilters && (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Difficulty</p>
                      <div className="flex flex-wrap gap-2">
                        {difficulties.map((difficulty) => (
                          <Button
                            key={difficulty}
                            variant={selectedDifficulty === difficulty ? "default" : "outline"}
                            size="sm"
                            onClick={() => setSelectedDifficulty(difficulty)}
                            className="text-xs"
                          >
                            {difficulty}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <Tabs defaultValue="exercises" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 h-12">
            <TabsTrigger value="exercises">Exercises</TabsTrigger>
            <TabsTrigger value="workouts">Workouts</TabsTrigger>
          </TabsList>

          <TabsContent value="exercises" className="space-y-4">
            {/* Exercise Grid */}
            <div className="space-y-4">
              {filteredExercises.map((exercise) => (
                <Card key={exercise.id} className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="flex space-x-4">
                      {/* Exercise Thumbnail */}
                      <div className="w-20 h-16 bg-gray-100 dark:bg-gray-700 rounded-lg flex-shrink-0 overflow-hidden">
                        <img
                          src={exercise.thumbnail || "/placeholder.svg"}
                          alt={exercise.name}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Exercise Info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-gray-900 dark:text-white text-base">{exercise.name}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">{exercise.description}</p>
                          </div>
                          <div className="flex items-center space-x-1 ml-2">
                            <Star className="w-3 h-3 text-yellow-500 fill-current" />
                            <span className="text-xs text-gray-600">{exercise.userRating}</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 mb-3">
                          <Badge className={getDifficultyColor(exercise.difficulty)} variant="secondary">
                            {exercise.difficulty}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {getCategoryIcon(exercise.category)}
                            <span className="ml-1">{exercise.category}</span>
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            <Clock className="w-3 h-3 mr-1" />
                            {exercise.duration}
                          </Badge>
                          {exercise.aiAnalysis && (
                            <Badge className="bg-purple-100 text-purple-800 text-xs">AI Analysis</Badge>
                          )}
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex flex-wrap gap-1">
                            {exercise.muscleGroups.slice(0, 2).map((muscle, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {muscle}
                              </Badge>
                            ))}
                            {exercise.muscleGroups.length > 2 && (
                              <Badge variant="secondary" className="text-xs">
                                +{exercise.muscleGroups.length - 2}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button variant="outline" size="sm">
                              <Play className="w-3 h-3 mr-1" />
                              Demo
                            </Button>
                            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                              <Target className="w-3 h-3 mr-1" />
                              Analyze
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredExercises.length === 0 && (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-8 text-center">
                  <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No exercises found</h3>
                  <p className="text-gray-600 dark:text-gray-400">Try adjusting your search or filter criteria</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="workouts" className="space-y-4">
            {/* Workout Templates */}
            <div className="space-y-4">
              {workoutTemplates.map((workout) => (
                <Card key={workout.id} className="border-0 shadow-sm">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white text-base">{workout.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{workout.description}</p>
                        </div>
                        <Badge className={getDifficultyColor(workout.difficulty)} variant="secondary">
                          {workout.difficulty}
                        </Badge>
                      </div>

                      <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{workout.duration}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Target className="w-4 h-4" />
                          <span>{workout.exercises} exercises</span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {workout.category}
                        </Badge>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Exercises:</p>
                        <div className="flex flex-wrap gap-1">
                          {workout.exercises_list.slice(0, 4).map((exercise, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {exercise}
                            </Badge>
                          ))}
                          {workout.exercises_list.length > 4 && (
                            <Badge variant="secondary" className="text-xs">
                              +{workout.exercises_list.length - 4} more
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button className="flex-1 bg-green-600 hover:bg-green-700">
                          <Play className="w-4 h-4 mr-2" />
                          Start Workout
                        </Button>
                        <Button variant="outline" size="sm">
                          Preview
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <BottomNavigation activeTab="library" />
    </div>
  )
}
