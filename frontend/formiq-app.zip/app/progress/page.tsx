"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  TrendingUp,
  TrendingDown,
  Target,
  Award,
  Activity,
  BarChart3,
  Calendar,
  Zap,
  FlameIcon as Fire,
} from "lucide-react"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Header } from "@/components/header"

const progressData = {
  currentStreak: 12,
  longestStreak: 18,
  totalWorkouts: 47,
  avgFormScore: 87,
  monthlyImprovement: 15,
  weeklyGoal: 5,
  weeklyProgress: 3,
}

const formTrends = [
  { period: "Week 1", depth: 78, stability: 72, tempo: 85, kneeTracking: 70, overall: 76 },
  { period: "Week 2", depth: 82, stability: 76, tempo: 88, kneeTracking: 74, overall: 80 },
  { period: "Week 3", depth: 85, stability: 80, tempo: 90, kneeTracking: 78, overall: 83 },
  { period: "Week 4", depth: 89, stability: 84, tempo: 92, kneeTracking: 82, overall: 87 },
]

const exerciseProgress = [
  {
    exercise: "Squat",
    current: 87,
    previous: 79,
    trend: "up",
    sessions: 12,
    bestScore: 94,
    issues: ["Knee tracking improved", "Depth consistent"],
  },
  {
    exercise: "Deadlift",
    current: 92,
    previous: 89,
    trend: "up",
    sessions: 8,
    bestScore: 96,
    issues: ["Perfect form", "Strong lockout"],
  },
  {
    exercise: "Bench Press",
    current: 82,
    previous: 85,
    trend: "down",
    sessions: 6,
    bestScore: 88,
    issues: ["Shoulder position", "Leg drive needs work"],
  },
  {
    exercise: "Overhead Press",
    current: 88,
    previous: 84,
    trend: "up",
    sessions: 5,
    bestScore: 91,
    issues: ["Good stability", "Full lockout achieved"],
  },
]

const achievements = [
  {
    id: 1,
    title: "Form Master",
    description: "Achieved 90+ form score",
    icon: "🏆",
    unlocked: true,
    date: "2 weeks ago",
    rarity: "Rare",
  },
  {
    id: 2,
    title: "Consistency King",
    description: "12-day workout streak",
    icon: "🔥",
    unlocked: true,
    date: "Today",
    rarity: "Epic",
  },
  {
    id: 3,
    title: "Perfect Squat",
    description: "100% squat form score",
    icon: "⭐",
    unlocked: false,
    progress: 94,
    rarity: "Legendary",
  },
  {
    id: 4,
    title: "AI Whisperer",
    description: "100 AI analyses completed",
    icon: "🤖",
    unlocked: false,
    progress: 67,
    rarity: "Epic",
  },
]

const weeklyActivity = [
  { day: "Mon", workouts: 1, formChecks: 2, score: 85 },
  { day: "Tue", workouts: 0, formChecks: 0, score: 0 },
  { day: "Wed", workouts: 1, formChecks: 3, score: 89 },
  { day: "Thu", workouts: 0, formChecks: 1, score: 82 },
  { day: "Fri", workouts: 1, formChecks: 2, score: 91 },
  { day: "Sat", workouts: 0, formChecks: 0, score: 0 },
  { day: "Sun", workouts: 1, formChecks: 1, score: 87 },
]

export default function ProgressTracker() {
  const [timeRange, setTimeRange] = useState("month")
  const [selectedMetric, setSelectedMetric] = useState("overall")

  const getTrendIcon = (trend: string) => {
    return trend === "up" ? (
      <TrendingUp className="w-4 h-4 text-green-500" />
    ) : (
      <TrendingDown className="w-4 h-4 text-red-500" />
    )
  }

  const getTrendColor = (trend: string) => {
    return trend === "up" ? "text-green-600" : "text-red-600"
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "Common":
        return "bg-gray-100 text-gray-800"
      case "Rare":
        return "bg-blue-100 text-blue-800"
      case "Epic":
        return "bg-purple-100 text-purple-800"
      case "Legendary":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      <Header />

      <div className="px-4 py-6 space-y-6">
        {/* Progress Header */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Your Progress</h1>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">3 Months</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                    <Target className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Avg Form Score</p>
                    <div className="flex items-center space-x-2">
                      <p className="text-xl font-bold text-gray-900 dark:text-white">{progressData.avgFormScore}%</p>
                      <Badge className="bg-green-100 text-green-800 text-xs">+{progressData.monthlyImprovement}%</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
                    <Fire className="w-5 h-5 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Current Streak</p>
                    <div className="flex items-center space-x-2">
                      <p className="text-xl font-bold text-gray-900 dark:text-white">{progressData.currentStreak}d</p>
                      <Badge className="bg-orange-100 text-orange-800 text-xs">Personal best!</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 h-12">
            <TabsTrigger value="overview" className="text-xs">
              Overview
            </TabsTrigger>
            <TabsTrigger value="form" className="text-xs">
              Form
            </TabsTrigger>
            <TabsTrigger value="workouts" className="text-xs">
              Workouts
            </TabsTrigger>
            <TabsTrigger value="achievements" className="text-xs">
              Awards
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Weekly Activity Heatmap */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-base">
                  <Calendar className="w-5 h-5 text-green-600" />
                  <span>Weekly Activity</span>
                </CardTitle>
                <CardDescription>Your workout and form check activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-7 gap-2">
                    {weeklyActivity.map((day, index) => (
                      <div key={index} className="text-center">
                        <p className="text-xs font-medium text-gray-600 dark:text-gray-400 mb-2">{day.day}</p>
                        <div
                          className={`w-full h-12 rounded-lg flex items-center justify-center ${
                            day.workouts > 0
                              ? "bg-green-100 dark:bg-green-900/20 border-2 border-green-500"
                              : "bg-gray-100 dark:bg-gray-700 border-2 border-gray-300 dark:border-gray-600"
                          }`}
                        >
                          <div className="text-center">
                            <p className="text-xs font-bold text-gray-900 dark:text-white">{day.workouts}</p>
                            <p className="text-xs text-gray-500">{day.formChecks > 0 ? `${day.formChecks}✓` : ""}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-blue-900 dark:text-blue-100">Weekly Goal Progress</p>
                      <p className="text-xs text-blue-700 dark:text-blue-200">
                        {progressData.weeklyProgress} of {progressData.weeklyGoal} workouts completed
                      </p>
                    </div>
                    <div className="text-right">
                      <Progress
                        value={(progressData.weeklyProgress / progressData.weeklyGoal) * 100}
                        className="w-20 h-2 mb-1"
                      />
                      <p className="text-xs text-blue-600">
                        {Math.round((progressData.weeklyProgress / progressData.weeklyGoal) * 100)}%
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-3">
              <Card className="border-0 shadow-sm">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Activity className="w-6 h-6 text-purple-600" />
                  </div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{progressData.totalWorkouts}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Workouts</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center mx-auto mb-2">
                    <Award className="w-6 h-6 text-yellow-600" />
                  </div>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{progressData.longestStreak}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Longest Streak</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="form" className="space-y-6">
            {/* Form Evolution Chart */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-base">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  <span>Form Evolution</span>
                </CardTitle>
                <CardDescription>Multi-dimensional form improvement tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {formTrends.map((period, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{period.period}</span>
                        <span className="text-sm font-bold text-gray-900 dark:text-white">
                          {period.overall}% overall
                        </span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center space-x-3">
                          <div className="w-16 text-xs text-gray-500">Depth</div>
                          <Progress value={period.depth} className="flex-1 h-2" />
                          <span className="text-xs font-medium w-8">{period.depth}%</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-16 text-xs text-gray-500">Stability</div>
                          <Progress value={period.stability} className="flex-1 h-2" />
                          <span className="text-xs font-medium w-8">{period.stability}%</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-16 text-xs text-gray-500">Tempo</div>
                          <Progress value={period.tempo} className="flex-1 h-2" />
                          <span className="text-xs font-medium w-8">{period.tempo}%</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-16 text-xs text-gray-500">Knees</div>
                          <Progress value={period.kneeTracking} className="flex-1 h-2" />
                          <span className="text-xs font-medium w-8">{period.kneeTracking}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Exercise-Specific Progress */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-base">
                  <Target className="w-5 h-5 text-purple-600" />
                  <span>Exercise Progress</span>
                </CardTitle>
                <CardDescription>Form scores by exercise type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {exerciseProgress.map((exercise, index) => (
                    <div key={index} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900 dark:text-white">{exercise.exercise}</h4>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {exercise.sessions} sessions • Best: {exercise.bestScore}%
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center space-x-2">
                            {getTrendIcon(exercise.trend)}
                            <span className="text-lg font-bold text-gray-900 dark:text-white">{exercise.current}%</span>
                          </div>
                          <span className={`text-sm font-medium ${getTrendColor(exercise.trend)}`}>
                            {exercise.trend === "up" ? "+" : ""}
                            {exercise.current - exercise.previous}% change
                          </span>
                        </div>
                      </div>
                      <Progress value={exercise.current} className="h-2 mb-3" />
                      <div className="flex flex-wrap gap-1">
                        {exercise.issues.map((issue, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {issue}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workouts" className="space-y-6">
            {/* Workout Statistics */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-base">
                  <BarChart3 className="w-5 h-5 text-green-600" />
                  <span>Workout Statistics</span>
                </CardTitle>
                <CardDescription>Your training patterns and consistency</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-4">
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600 mb-1">4.2</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Avg Workouts/Week</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-green-600 mb-1">42 min</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Avg Duration</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600 mb-1">2.8</div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Form Checks/Workout</div>
                    </div>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                        <Zap className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-green-900 dark:text-green-100">Consistency Streak</h4>
                        <p className="text-sm text-green-700 dark:text-green-200">
                          You've been consistent for {progressData.currentStreak} days! Keep it up!
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            {/* Achievements */}
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-base">
                  <Award className="w-5 h-5 text-yellow-600" />
                  <span>Achievements</span>
                </CardTitle>
                <CardDescription>Your fitness milestones and accomplishments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.map((achievement) => (
                    <div
                      key={achievement.id}
                      className={`p-4 rounded-lg border-2 ${
                        achievement.unlocked
                          ? "bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-yellow-200 dark:border-yellow-800"
                          : "bg-gray-50 dark:bg-gray-700 border-gray-200 dark:border-gray-600"
                      }`}
                    >
                      <div className="flex items-start space-x-4">
                        <div className={`text-3xl ${achievement.unlocked ? "" : "grayscale opacity-50"}`}>
                          {achievement.icon}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h4
                              className={`font-medium ${
                                achievement.unlocked
                                  ? "text-gray-900 dark:text-white"
                                  : "text-gray-500 dark:text-gray-400"
                              }`}
                            >
                              {achievement.title}
                            </h4>
                            <div className="flex items-center space-x-2">
                              <Badge className={getRarityColor(achievement.rarity)} variant="secondary">
                                {achievement.rarity}
                              </Badge>
                              {achievement.unlocked && (
                                <Badge className="bg-yellow-100 text-yellow-800">Unlocked</Badge>
                              )}
                            </div>
                          </div>
                          <p
                            className={`text-sm ${
                              achievement.unlocked
                                ? "text-gray-600 dark:text-gray-300"
                                : "text-gray-500 dark:text-gray-400"
                            }`}
                          >
                            {achievement.description}
                          </p>
                          {achievement.unlocked ? (
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Unlocked {achievement.date}</p>
                          ) : (
                            <div className="mt-3">
                              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                                <span>Progress</span>
                                <span>{achievement.progress}%</span>
                              </div>
                              <Progress value={achievement.progress} className="h-2" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <BottomNavigation activeTab="progress" />
    </div>
  )
}
