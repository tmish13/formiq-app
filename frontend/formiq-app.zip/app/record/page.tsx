"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Camera, Upload, RotateCcw, Square, Eye, Target, CheckCircle } from "lucide-react"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Header } from "@/components/header"

const exercises = [
  {
    value: "squat",
    label: "Squat",
    icon: "🏋️",
    description: "Lower body compound movement",
    keyPoints: ["Full body visible", "Side angle preferred", "3-5 controlled reps"],
  },
  {
    value: "deadlift",
    label: "Deadlift",
    icon: "💪",
    description: "Hip hinge movement pattern",
    keyPoints: ["Side view essential", "Bar path visible", "Complete range of motion"],
  },
  {
    value: "bench-press",
    label: "Bench Press",
    icon: "🏃",
    description: "Upper body pressing movement",
    keyPoints: ["Side view preferred", "Full setup visible", "Controlled tempo"],
  },
  {
    value: "overhead-press",
    label: "Overhead Press",
    icon: "🤸",
    description: "Vertical pressing movement",
    keyPoints: ["Front or side view", "Full body in frame", "Complete lockout"],
  },
]

const recordingTips = [
  {
    icon: "📱",
    title: "Phone Position",
    description: "Place phone 6-8 feet away at chest height",
  },
  {
    icon: "💡",
    title: "Lighting",
    description: "Ensure good lighting with minimal shadows",
  },
  {
    icon: "👤",
    title: "Framing",
    description: "Keep your entire body visible in frame",
  },
  {
    icon: "🎯",
    title: "Reps",
    description: "Perform 3-5 controlled repetitions",
  },
]

export default function RecordScreen() {
  const [selectedExercise, setSelectedExercise] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [showPoseOverlay, setShowPoseOverlay] = useState(true)
  const [cameraPermission, setCameraPermission] = useState<"granted" | "denied" | "prompt">("prompt")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime((prev) => prev + 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [isRecording])

  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true })
      setCameraPermission("granted")
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
    } catch (error) {
      setCameraPermission("denied")
    }
  }

  const handleStartRecording = () => {
    if (!selectedExercise) return
    setIsRecording(true)
    setRecordingTime(0)
  }

  const handleStopRecording = () => {
    setIsRecording(false)
    // Navigate to analysis results
  }

  const handleFileUpload = () => {
    fileInputRef.current?.click()
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const selectedExerciseData = exercises.find((ex) => ex.value === selectedExercise)

  return (
    <div className="min-h-screen bg-gray-900 pb-20">
      <Header variant="dark" />

      <div className="relative h-screen">
        {/* Camera View */}
        <div className="absolute inset-0">
          {cameraPermission === "granted" ? (
            <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              <div className="text-center text-white space-y-4">
                <Camera className="w-16 h-16 mx-auto text-gray-400" />
                <div>
                  <h3 className="text-xl font-semibold mb-2">Camera Access Required</h3>
                  <p className="text-gray-300 mb-4">Allow camera access to start form analysis</p>
                  <Button onClick={requestCameraPermission} className="bg-blue-600 hover:bg-blue-700">
                    <Camera className="w-4 h-4 mr-2" />
                    Enable Camera
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Pose Overlay (when enabled and recording) */}
          {showPoseOverlay && isRecording && (
            <div className="absolute inset-0 pointer-events-none">
              <svg className="w-full h-full">
                {/* Skeleton overlay points */}
                <circle cx="50%" cy="20%" r="4" fill="#3B82F6" opacity="0.8" />
                <circle cx="45%" cy="35%" r="3" fill="#3B82F6" opacity="0.8" />
                <circle cx="55%" cy="35%" r="3" fill="#3B82F6" opacity="0.8" />
                <circle cx="50%" cy="50%" r="3" fill="#10B981" opacity="0.8" />
                <circle cx="40%" cy="70%" r="3" fill="#F59E0B" opacity="0.8" />
                <circle cx="60%" cy="70%" r="3" fill="#F59E0B" opacity="0.8" />
                <circle cx="45%" cy="85%" r="3" fill="#3B82F6" opacity="0.8" />
                <circle cx="55%" cy="85%" r="3" fill="#3B82F6" opacity="0.8" />

                {/* Connecting lines */}
                <line x1="50%" y1="20%" x2="50%" y2="50%" stroke="#3B82F6" strokeWidth="2" opacity="0.6" />
                <line x1="45%" y1="35%" x2="55%" y2="35%" stroke="#3B82F6" strokeWidth="2" opacity="0.6" />
                <line x1="50%" y1="50%" x2="40%" y2="70%" stroke="#10B981" strokeWidth="2" opacity="0.6" />
                <line x1="50%" y1="50%" x2="60%" y2="70%" stroke="#10B981" strokeWidth="2" opacity="0.6" />
                <line x1="40%" y1="70%" x2="45%" y2="85%" stroke="#F59E0B" strokeWidth="2" opacity="0.6" />
                <line x1="60%" y1="70%" x2="55%" y2="85%" stroke="#F59E0B" strokeWidth="2" opacity="0.6" />
              </svg>
            </div>
          )}

          {/* Recording Indicator */}
          {isRecording && (
            <div className="absolute top-4 left-4 flex items-center space-x-2 bg-red-500 text-white px-3 py-2 rounded-full">
              <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
              <span className="font-medium">{formatTime(recordingTime)}</span>
            </div>
          )}

          {/* AI Status Indicator */}
          {cameraPermission === "granted" && (
            <div className="absolute top-4 right-4 flex items-center space-x-2 bg-black/50 text-white px-3 py-2 rounded-full">
              <Eye className="w-4 h-4" />
              <span className="text-sm">AI Ready</span>
            </div>
          )}

          {/* Exercise Selection Overlay */}
          {!selectedExercise && cameraPermission === "granted" && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center p-4">
              <Card className="w-full max-w-md">
                <CardContent className="p-6 space-y-4">
                  <div className="text-center">
                    <Target className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Select Exercise</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Choose the exercise you want to analyze</p>
                  </div>

                  <Select value={selectedExercise} onValueChange={setSelectedExercise}>
                    <SelectTrigger className="h-12">
                      <SelectValue placeholder="Choose exercise for AI analysis" />
                    </SelectTrigger>
                    <SelectContent>
                      {exercises.map((exercise) => (
                        <SelectItem key={exercise.value} value={exercise.value}>
                          <div className="flex items-center space-x-3 py-2">
                            <span className="text-lg">{exercise.icon}</span>
                            <div>
                              <p className="font-medium">{exercise.label}</p>
                              <p className="text-xs text-gray-500">{exercise.description}</p>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Exercise Info Panel */}
          {selectedExercise && selectedExerciseData && !isRecording && (
            <div className="absolute bottom-32 left-4 right-4">
              <Card className="bg-black/80 text-white border-0">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <span className="text-2xl">{selectedExerciseData.icon}</span>
                    <div>
                      <h4 className="font-semibold">{selectedExerciseData.label}</h4>
                      <p className="text-sm text-gray-300">{selectedExerciseData.description}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {selectedExerciseData.keyPoints.map((point, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                        <span className="text-sm">{point}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Bottom Controls */}
          <div className="absolute bottom-24 left-0 right-0 px-4">
            <div className="flex items-center justify-center space-x-6">
              {/* Upload Button */}
              <Button
                variant="outline"
                size="lg"
                onClick={handleFileUpload}
                disabled={isRecording}
                className="bg-black/50 border-white/20 text-white hover:bg-black/70 h-14 px-6"
              >
                <Upload className="w-5 h-5 mr-2" />
                Upload
              </Button>

              {/* Record Button */}
              <div className="relative">
                <Button
                  size="lg"
                  onClick={isRecording ? handleStopRecording : handleStartRecording}
                  disabled={!selectedExercise}
                  className={`w-20 h-20 rounded-full border-4 border-white ${
                    isRecording
                      ? "bg-red-500 hover:bg-red-600"
                      : selectedExercise
                        ? "bg-blue-600 hover:bg-blue-700"
                        : "bg-gray-400"
                  }`}
                >
                  {isRecording ? (
                    <Square className="w-8 h-8 fill-current" />
                  ) : (
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                      <div className="w-6 h-6 bg-current rounded-full" />
                    </div>
                  )}
                </Button>
                {isRecording && (
                  <div className="absolute -inset-2 border-4 border-red-500 rounded-full animate-pulse" />
                )}
              </div>

              {/* Settings Button */}
              <Button
                variant="outline"
                size="lg"
                onClick={() => setShowPoseOverlay(!showPoseOverlay)}
                disabled={isRecording}
                className="bg-black/50 border-white/20 text-white hover:bg-black/70 h-14 px-6"
              >
                <Eye className={`w-5 h-5 mr-2 ${showPoseOverlay ? "text-blue-400" : ""}`} />
                Overlay
              </Button>
            </div>

            {/* Exercise Change Button */}
            {selectedExercise && !isRecording && (
              <div className="flex justify-center mt-4">
                <Button
                  variant="ghost"
                  onClick={() => setSelectedExercise("")}
                  className="text-white hover:bg-white/10"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Change Exercise
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.[0]) {
              // Handle file upload and navigate to analysis
            }
          }}
        />
      </div>

      <BottomNavigation activeTab="record" />
    </div>
  )
}
