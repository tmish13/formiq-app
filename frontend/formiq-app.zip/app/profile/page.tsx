"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Settings,
  User,
  Bell,
  Shield,
  HelpCircle,
  LogOut,
  Crown,
  Target,
  Award,
  Moon,
  ChevronRight,
  Camera,
  Edit,
} from "lucide-react"
import { BottomNavigation } from "@/components/bottom-navigation"
import { Header } from "@/components/header"

const userProfile = {
  name: "Alex Johnson",
  email: "alex.johnson@email.com",
  joinDate: "January 2024",
  avatar: "/placeholder.svg?height=80&width=80",
  subscription: "Pro",
  stats: {
    totalWorkouts: 47,
    avgFormScore: 87,
    currentStreak: 12,
    longestStreak: 18,
    totalAnalyses: 156,
    improvementRate: 23,
  },
  achievements: [
    { name: "Form Master", icon: "🏆", unlocked: true },
    { name: "Consistency King", icon: "🔥", unlocked: true },
    { name: "Perfect Form", icon: "⭐", unlocked: false },
  ],
  preferences: {
    notifications: true,
    darkMode: false,
    aiCoaching: true,
    dataSharing: false,
  },
}

const menuSections = [
  {
    title: "Account",
    items: [
      { icon: User, label: "Personal Information", action: "personal" },
      { icon: Crown, label: "Subscription", action: "subscription", badge: "Pro" },
      { icon: Target, label: "Goals & Preferences", action: "goals" },
    ],
  },
  {
    title: "App Settings",
    items: [
      { icon: Bell, label: "Notifications", action: "notifications", toggle: true },
      { icon: Moon, label: "Dark Mode", action: "darkMode", toggle: true },
      { icon: Shield, label: "Privacy & Data", action: "privacy" },
    ],
  },
  {
    title: "Support",
    items: [
      { icon: HelpCircle, label: "Help & FAQ", action: "help" },
      { icon: Settings, label: "App Settings", action: "settings" },
      { icon: LogOut, label: "Sign Out", action: "logout", danger: true },
    ],
  },
]

export default function ProfileScreen() {
  const [darkMode, setDarkMode] = useState(userProfile.preferences.darkMode)
  const [notifications, setNotifications] = useState(userProfile.preferences.notifications)

  const handleToggle = (setting: string, value: boolean) => {
    if (setting === "darkMode") {
      setDarkMode(value)
    } else if (setting === "notifications") {
      setNotifications(value)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 pb-20">
      <Header />

      <div className="px-4 py-6 space-y-6">
        {/* Profile Header */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={userProfile.avatar || "/placeholder.svg"} alt={userProfile.name} />
                  <AvatarFallback className="text-lg font-semibold bg-blue-100 text-blue-600">
                    {userProfile.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <Button
                  size="sm"
                  className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-blue-600 hover:bg-blue-700 p-0"
                >
                  <Camera className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">{userProfile.name}</h2>
                  <Badge className="bg-purple-100 text-purple-800">
                    <Crown className="w-3 h-3 mr-1" />
                    {userProfile.subscription}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">{userProfile.email}</p>
                <p className="text-xs text-gray-500 dark:text-gray-500">Member since {userProfile.joinDate}</p>
              </div>
              <Button variant="outline" size="sm">
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Your Stats</CardTitle>
            <CardDescription>Your fitness journey at a glance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{userProfile.stats.totalWorkouts}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Total Workouts</div>
              </div>
              <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{userProfile.stats.avgFormScore}%</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Avg Form Score</div>
              </div>
              <div className="text-center p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <div className="text-2xl font-bold text-orange-600">{userProfile.stats.currentStreak}d</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">Current Streak</div>
              </div>
              <div className="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <div className="text-2xl font-bold text-purple-600">{userProfile.stats.totalAnalyses}</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">AI Analyses</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Achievements */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-base">
              <Award className="w-5 h-5 text-yellow-600" />
              <span>Recent Achievements</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-3">
              {userProfile.achievements.map((achievement, index) => (
                <div
                  key={index}
                  className={`flex-1 text-center p-3 rounded-lg ${
                    achievement.unlocked
                      ? "bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800"
                      : "bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600"
                  }`}
                >
                  <div className={`text-2xl mb-1 ${achievement.unlocked ? "" : "grayscale opacity-50"}`}>
                    {achievement.icon}
                  </div>
                  <p className="text-xs font-medium text-gray-700 dark:text-gray-300">{achievement.name}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Menu Sections */}
        <div className="space-y-6">
          {menuSections.map((section, sectionIndex) => (
            <Card key={sectionIndex} className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-gray-700 dark:text-gray-300">{section.title}</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-1">
                  {section.items.map((item, itemIndex) => (
                    <div
                      key={itemIndex}
                      className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            item.danger ? "bg-red-100 dark:bg-red-900/20" : "bg-gray-100 dark:bg-gray-700"
                          }`}
                        >
                          <item.icon
                            className={`w-4 h-4 ${
                              item.danger ? "text-red-600 dark:text-red-400" : "text-gray-600 dark:text-gray-400"
                            }`}
                          />
                        </div>
                        <span
                          className={`font-medium ${
                            item.danger ? "text-red-600 dark:text-red-400" : "text-gray-900 dark:text-white"
                          }`}
                        >
                          {item.label}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {item.badge && <Badge className="bg-purple-100 text-purple-800 text-xs">{item.badge}</Badge>}
                        {item.toggle ? (
                          <Switch
                            checked={item.action === "darkMode" ? darkMode : notifications}
                            onCheckedChange={(checked) => handleToggle(item.action, checked)}
                          />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-gray-400" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* App Info */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4 text-center">
            <div className="space-y-2">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white">FormIQ</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Version 2.1.0</p>
              <p className="text-xs text-gray-500 dark:text-gray-500">AI-powered fitness form analysis</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNavigation activeTab="profile" />
    </div>
  )
}
