"use client"

import { Button } from "@/components/ui/button"
import { Home, Camera, TrendingUp, BookOpen, User } from "lucide-react"
import { useRouter } from "next/navigation"

interface BottomNavigationProps {
  activeTab: "home" | "record" | "progress" | "library" | "profile"
}

export function BottomNavigation({ activeTab }: BottomNavigationProps) {
  const router = useRouter()

  const navItems = [
    { id: "home", icon: Home, label: "Home", path: "/" },
    { id: "record", icon: Camera, label: "Record", path: "/record" },
    { id: "progress", icon: TrendingUp, label: "Progress", path: "/progress" },
    { id: "library", icon: BookOpen, label: "Library", path: "/library" },
    { id: "profile", icon: User, label: "Profile", path: "/profile" },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 safe-area-bottom">
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => (
          <Button
            key={item.id}
            variant="ghost"
            className={`flex flex-col items-center justify-center h-full space-y-1 rounded-none ${
              activeTab === item.id
                ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/20"
                : "text-gray-600 dark:text-gray-400"
            }`}
            onClick={() => router.push(item.path)}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-xs font-medium">{item.label}</span>
          </Button>
        ))}
      </div>
    </div>
  )
}
